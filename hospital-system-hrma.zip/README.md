
# Hospital System HRMA

Simple Hospital Management System  
Backend → Node.js + Express + MongoDB  
Frontend → HTML + CSS + JS  

Deploy:
- Backend: Render.com
- Frontend: Netlify.com
