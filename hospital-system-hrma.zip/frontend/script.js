
const API = "https://your-backend.onrender.com/patients";

async function addPatient() {
  const name = document.getElementById("name").value;
  const age = document.getElementById("age").value;
  const disease = document.getElementById("disease").value;

  await fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, age, disease }),
  });

  loadPatients();
}

async function loadPatients() {
  const res = await fetch(API);
  const data = await res.json();

  document.getElementById("list").innerHTML = data
    .map((p) => `<p><b>${p.name}</b> (${p.age}) – ${p.disease}</p>`)
    .join("");
}

loadPatients();
