
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

connectDB();

app.use("/patients", require("./routes/patients"));

app.get("/", (req, res) => res.send("Hospital System HRMA API Running"));

app.listen(5000, () => console.log("Server running on port 5000"));
